#!/bin/bash
sshpass -p "wallwb13" scp Server.c pi@192.168.100.18:~/

