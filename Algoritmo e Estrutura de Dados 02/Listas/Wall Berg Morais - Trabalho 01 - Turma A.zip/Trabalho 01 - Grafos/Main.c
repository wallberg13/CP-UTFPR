#include "Grafos.c"
#include "Menus.c"

int main(){
  menu();
}