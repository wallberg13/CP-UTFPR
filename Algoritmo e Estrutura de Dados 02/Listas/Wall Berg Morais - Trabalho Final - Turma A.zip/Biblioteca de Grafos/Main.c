#include "Grafos.c"
#include "Menus.c"
#include "Buscas.c"

int main(){
  menu();
}
