#include "Funcoes.h"

int main(){
  sub_main();
}