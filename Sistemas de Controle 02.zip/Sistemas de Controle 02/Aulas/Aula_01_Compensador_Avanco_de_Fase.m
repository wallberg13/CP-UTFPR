s = tf('s');

%Para achar o ganho.
%Coloca o S no ponto para achar o ganho
%Ent�o coloca na equa��o K = 1/abs(Gc*Gs);

% Planta
Gs = 10/(s*(s+1));

%Compensador via metodo geometrico
Gc1 = (s + 1.9432)/(s + 4.6458);

%Compensador via cancelamento de polos
Gc2 = (s + 1)/(s + 3);

K1 = 1.2287;
K2 = 0.90;

%Sistema malha fechada com compensador 01
T1 = feedback(K1*Gc1*Gs,1);
%Sistema malha fechada com compensador 02
T2 = feedback(K2*Gc2*Gs,1);
%Sistema malha fechada sem compensador.
T = feedback(Gs,1);

step(T,T1,T2);
legend('Sem compensador','CC 01','CC 02');

%% Exercicios 10/03/2017

% Manter o %UP de 30% e o tempo de assentamento diminuir pela 
% metade.
s = tf('s');

Gs = 1/(s*(s+4)*(s+6));

rltool;

% J� tendo o objetivo, ent�o � s� achar o quanto de angulo 
% que falta. Zc2 = -4
x = -2.014 + j*5.252 %objetivo
y = (x + 4)/(x*(x+4)*(x+6)) 
quant = pi - abs(angle(y));
pc = imag(x)/tan(quant) - real(x)

% Zc3 = -2
x = -2.014 + j*5.252 %objetivo
y = (x + 2)/(x*(x+4)*(x+6)) 
quant = pi - abs(angle(y));
pc = imag(x)/tan(quant) - real(x)

% Achando os K, sabendo que x � o objetivo
% Compensador 
Gc1 = (s+5)/(s+42.934);
Gc2 = (s+4)/(s+20.0725);
Gc3 = (s+2)/(s+8.9628);

x = -2.014 + j*5.252 %objetivo
y = (x + 4)/(x*(x+4)*(x+6)) 
Gx1 = (x+5)/(x+42.934);
Gx2 = (x+4)/(x+20.0725);
Gx3 = (x+2)/(x+8.9628);


k1 = 1/abs((y*Gx1));
k2 = 1/abs((y*Gx2));
k3 = 1/abs((y*Gx3));
k = 63.2;

% Malha fechada
T1 = feedback(k1*Gc1*Gs,1);
T2 = feedback(k2*Gc2*Gs,1);
T3 = feedback(k3*Gc3*Gs,1);
T = feedback(k*Gs,1);

% Resposta ao degrau
step(T1,T2,T3,T);
legend('T1','T2','T3','T')