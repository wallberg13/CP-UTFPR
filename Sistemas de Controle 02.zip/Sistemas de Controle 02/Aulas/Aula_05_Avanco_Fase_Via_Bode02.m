clear all;
clc;
s = tf('s');
K = 1000;
Gs = 1/(s*(s+5)*(s+20));
Gs1 = K*Gs;
%achando o alpha
syms x;
a = solve(sin(22.5*pi/180) == (1-x)/(1+x))
bode(K*Gs);
aux1 = -20*log10(1/sqrt(a)); %Procurar a frequencia que passa nessa amplitude
Gc = (1000/0.4465)*(s+5.11)/(s+11.43);

bode(Gc*Gs);

%% Aula 06 - Outro Exemplo
clear all;
clc;
s = tf('s');
Gs = 1/((s+2)*(s+5)*(s+7));
K1 = 211.34;
bode(K1*Gs);
Gs1 = K1*Gs;
K = 6.62;
bode(K*Gs1);
B = 7.5;
Gc = (K/B)*((s + 0.341)/(s + 0.04546));
bode(Gs1*Gc);



%% Exemplo Dia 12/05/2017 ===> Via Ziegels Nichols

s = tf('s');
Gs = (s+6)/((s+2)*(s+3)*(s+4));
step(Gs);
grid on;
Kp = 10; Ti = 1; Kd = 0.075;
Gc = Kp*(1 + 1/(Ti*s) + Kd*s);
step(feedback(Gs*Gc,1));