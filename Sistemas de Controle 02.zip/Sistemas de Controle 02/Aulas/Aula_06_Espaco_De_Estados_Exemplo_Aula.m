%%

clear all;
clc;

A = [-7 1 0; 0 -8 1; 0 0 9]
B = [0; 0; 1]
C = [-1 1 0]

Cmz = [B A*B A^2*B]

s = tf('s');

[num, den] = ss2tf(A,B,C,0)
Gs = tf(num,den);

A1 = [0 1 0; 0 0 1; 504 79 -6];
B1 = [0; 0; 1];
C1 = [6 1 0];

ep = -log(0.2)/((pi^2 + log(0.2)^2)^0.5)
wn = 4/(2*ep);

Sobj = ep*wn + i*wn*(1 - ep^2)^.5