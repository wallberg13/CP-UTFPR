clear all;
clc;

%% Resolver equacao simbolica

syms x;
y = solve(sin(41*pi/180) == (1-x)/(1+x));

%%
Gdb = 20*log10(1/sqrt(y));
s = tf('s');
K = 240;
Gs = 100/(s*(s+6)*(s+100));

bode(K*Gs)

Gs = 1/((s+50)*(s+120))