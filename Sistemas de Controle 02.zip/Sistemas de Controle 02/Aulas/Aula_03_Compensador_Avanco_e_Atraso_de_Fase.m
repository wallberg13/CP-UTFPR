%% Compensador Avan�o e Atraso de Fase.
% Algoritmo:
% Pegando as especifica��es do problema:
% Epslon, wn, ou kv, kp..tanto faz.
% =========================================================================
% � bom de inicio selecionar uma posi��o para o zero do Compensador do
% avan�o de fase.
% =========================================================================
% Pegando primeiro o avan�o, e pegando o polinomio caracteristico,
% calcula-se o polo objetivo
% Planta: 4/s(s+5);
wn = 5;
ep = 0.5;
Zav = 0.5;
Kv = 80;
Sob = roots([1 2*ep*wn wn^2]);
Sob = Sob(2);

% Descobre-se ent�o a contribui��o angular deste polo no Gs (aqui � em rad)
% Gs no polo objetivo
Gs = 4/(Sob*(Sob+0.5));
ang = 180 + rad2deg(angle(Gs)); % Angulo de contribui��o do polo objetivo
ang2 = 180 + rad2deg(angle((s+Zav)*Gs); % Angulo que falta depois da contribui��o
% Dada pelo o Zero que foi adicionado no sistema. 
s = tf('s');
Kv = 6.25;
Gc = ((s + 0.5)*(s + 0.2))/((s + 5)*(s + 0.0125));
Gs = 4/(s*(s+0.5));


Tc = feedback(Kv*Gs*Gc,1);
T = feedback(Gs,1);
step(1/s,T/s,Tc/s);
legend('In','T','Tc');