clear all;
close all;
clc;

dt = 1e-6;
tempo = 0:dt:0.5;
vc = zeros(1,length(tempo));
iL = zeros(1,length(tempo));

x1 = [0; 0];
R = 1;
L = 400e-6;
C = 100e-6;
E = 1;

A = [ -R/L -1/L ; 1/C 0];

B = [ 1/L ; 0];

for k = 2:length(tempo)
    x = (A*x1 + B*E)*dt + x1;
    iL(k) = x(1);
    vc(k) = x(2);
    x1 = x;
end

figure()
plot(tempo,vc);
xlim([0 0.01])
figure()
plot(tempo,iL);
xlim([0 0.01]);
