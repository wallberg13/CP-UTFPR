%% Comandos para fazer a configura��o do KIT de Aquisi��o
daqreset
daqregister('nidaq')
daq.getDevices

plot(resposta);
grib;

s = tf('s');
Gs = 43.66982978/(s^2 + 3.375*s + 43.66982978);


plot(resposta);
hold on;
step(2.7*Gs + 2.2);
grid;