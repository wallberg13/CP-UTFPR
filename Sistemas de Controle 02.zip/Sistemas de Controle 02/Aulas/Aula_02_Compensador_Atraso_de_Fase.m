%% Compensador por Atraso de Fase - Exercicio 01

clear all;
clc;

s = tf('s');
G = 1.06/(s*(s+1)*(s+2));
Gc = (s+0.05)/(s+0.005);
rlocus(G, Gc*G);

%% Rampa
T = feedback(G,1);
T2 = feedback(G*Gc,1);

%% Aplicando a Rampa
figure();
step(T/s, T2/s, 1/s);
legend('SC','CC','In');

%%
%%
%% Compensador por Atraso de Fase - Exercicio 02

clear all;
clc;

s = tf('s');
G = 1/(s*(s+10)*(s+1)*(s+2));
Gc1 = (s+0.05)/(s+0.005);
Gc2 = (s+0.01)/(s+0.001);


%% Rampa
T = feedback(G,1);
T2 = feedback(G*Gc1,1);
T3 = feedback(G*Gc2,1);

%% Aplicando a Rampa
figure();
step(T, T2,T3);
legend('SC','CC1','CC2');