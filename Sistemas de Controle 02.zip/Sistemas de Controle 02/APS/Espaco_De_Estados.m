clear all;
close all;
clc;

% Defini��es - Dados de Projeto.

E = 24;     % Tens�o de Entrada
Vd = 0.7;   % Tens�o de Queda do Diodo
DIl = 0.2;  % Param�tro de varia��o M�xima na corrente
DVc = 1.2;  % Param�tro de varia��o M�xima no capacitor
f = 50e3;   % Frequ�ncia de Chaveamento
R = 12;   % Resistor de pelo menos 12W

L = E/(4*DIl*f);
C = E/(31*DVc*L*(f)^2);

%% Controle

dt = 1e-6;
tempo = 0:dt:.01;
vc = zeros(1,length(tempo));
il = zeros(1,length(tempo));
x1 = [0 ; 0];

A1 = [-1/(R*C) 1/C ; -1/L 0]; %[VC ; IL]
B1 = [0 ; 1/L]; %[il ; vc]

%%A2 = [-1/(R*C) 1/C; -1/L 0]; %[vc ; il];
%%B2 = [0 ; -1/L]; %[vc ; il];

for k = 2:length(tempo)
    x = (A1*x1 + B1*E)*dt + x1;
    vc(k) = x(1);
    il(k) = x(2);
    x1 = x;
end

plot(tempo,vc);
