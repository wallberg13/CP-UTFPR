clear all;
clc;

%% Tempo V_pi
x = load('Acao_controle.txt');

figure();
plot(1000*x(:,1),x(:,2));
grid on;
xlabel('Tempo(ms)');
ylabel('Tens�o(V)');
title('Gr�fico da Sa�da do Controlador PI (A��o de Controle)');

%% time	V(vb)
% Chaveamento
x = load('Chaveamento.txt');

figure();
plot(1000*x(:,1),x(:,2));
grid on;
xlabel('Tempo(ms)');
ylabel('Tens�o(V)');
title('Tens�o entre Dreno e Source no intervalo de 6 a 6.1ms');
xlim([6 6.1]);

%% time	V(vcarga)	V(n013)
% Condicionamento

x = load('Condicionamento.txt');

figure();
plot(1000*x(:,1),x(:,2),1000*x(:,1),x(:,3));
grid on;
xlabel('Tempo(ms)');
ylabel('Tens�o(V)');
title('Gr�fico do Circuito de condicionamento do sinal');
legend('Sinal da Carga dividido por dois','Sinal da Carga');

%% E_t Erro time	V(e_t)
x = load('E_t.txt');

figure();
plot(1000*x(:,1),x(:,2));
grid on;
xlabel('Tempo(ms)');
ylabel('Tens�o(V)');
title('Sinal do Erro');

%% time	V(vcarga)	V(vref)
% Ref e Vcarga
x = load('Ref_VCarga.txt');

figure();
plot(1000*x(:,1),x(:,2),1000*x(:,1),x(:,3));
grid on;
xlabel('Tempo(ms)');
ylabel('Tens�o(V)');
title('Gr�ficos do sinal de refer�ncia e o sinal da carga');
legend('Sinal da Carga','Sinal de Referencia');


%% time	V(Va,Vb)
% Sa�da
x = load('Saida_Carga.txt');

figure();
plot(1000*x(:,1),x(:,2));
grid on;
xlabel('Tempo(ms)');
ylabel('Tens�o(V)');
title('Sinal de Sa�da do Circuito - Tens�o na Carga');
