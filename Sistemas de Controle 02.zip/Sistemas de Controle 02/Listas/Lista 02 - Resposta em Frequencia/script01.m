%% Quest�o 01 - a


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                    %
%  im = atan((2*ep)/(-2ep^2 + (1 + 4ep^4)^.5)^.5);  %
%  
%
%   Avanco
%   G(s) = Kc*(s + 1/t)/(s + 1/alpha*t);
%   alpha = (1 - sen(Im))/(1 + sen(Im);
%   -20log10(1/raiz(alpha))
%   Atraso
%   G(s) = Kc*(s + 1/t)/(s + 1/beta*t);
%   beta = K/Kc
%   
%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear all;
clc;

s = tf('s');
G = 1/((s + 4)*(s + 10)*(s + 15));
bode(G);
K1 = 2113.49;
K2 = 2371.37;
Gs1 = K2*G;

bode(Gs1);

%% Quest�o 01 - b

clear all;
clc;

s = tf('s');
Gs = 1/(s*(s+4)*(s+10));
K = 177.83;
bode(K*Gs);

%% Quest�o 01 - c
clear all;
clc;

s = tf('s');
Gs = (s + 2)/(s*(s+4)*(s+6)*(s+10));
bode(feedback(Gs,1));
K = 489.78;
bode(feedback(K*Gs,1));

%% Quest�o 05 

clear all;
clc;
s = tf('s');
Gs = 1/(s*(s+7));
Gs1 = 45.19*Gs;
GsTest = 7.74*Gs1;
bode(GsTest);

%%
clear all;
clc;
s = tf('s');
Gs = 4/(s*(s+2));
bode(10*Gs);
