%% Quest�o 10 - Avan�o de Fase

clear all;
clc;
s = tf('s');
Gs = 1/s^2;
Up = 16.3/100; % � dada uma porcentagem percentual
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);
Ts = feedback(Gs,1);
Tso = 1.667;
Wno = 4/(Tso*ep);

Sobj = -ep*Wno + i*Wno*(1-ep^2)^.5
Gso = 1/Sobj^2;
angleX = radtodeg(angle(Gso*(Sobj+1)))


Gc = (s + 1)/(s + 6.07);
Gcs = (Sobj + 1)/(Sobj + 6.07);
Gso = 1/Sobj^2;
K = 1/abs(Gso*Gcs);
Gcc = K*Gc*Gs;
Tsc = feedback(K*Gc*Gs,1);
step(Ts,Tsc);

%% Quest�o 11

clear all;
clc;
s = tf('s');
Gs = (s+6)/((s+3)*(s+4)*(s+7)*(s+9));
K1 = 46.4;
Ts = feedback(K1*Gs,1);
%step(Ts);
Wno = 5;
ep = 0.8;
x = -Wno*ep + i*Wno*(1-ep^2)^.5;
Gso = (x+6)/((x+3)*(x+4)*(x+7)*(x+9));

angleX = radtodeg(angle(Gso*(x + 4.5)));

Gc = (s + 4.5)/(s + 7.28);
Gco = (x + 4.5)/(x + 7.28);

K = 1/abs(Gco*Gso);
Tsc = feedback(K*Gc*Gs,1);

step(Tsc,Ts);

%% Quest�o 13

clear all;
clc;
s = tf('s');
Gs = 1/(s*(s+20)*(s+40));
K1 = 9270;
Ts = feedback(K1*Gs,1);

ep = 0.4559;
wn = 28.53;
x = -ep*wn + i*wn*(1 - ep^2)^.5
Gsx = 1/(x*(x+20)*(x+40));
Zc = 20;
angleX = radtodeg(angle((x+20)*Gsx));

angC = 180 + angleX;
Pc = imag(x)/tan(degtorad(angC)) - real(x);
Gc = (s + Zc)/(s + Pc);
Gcx = (x + Zc)/(x + Pc);

K = abs(Gcx*Gsx)^-1;

Tsc = feedback(K*Gc*Gs,1);

step(Tsc,Ts);
grid on;
legend('Tsc','Ts');

%% Quest�o 14

clear all;
clc;
s = tf('s');
Gs = 1/((s+15)*(s^2 + 6*s + 13));

Up = 30/100; % � dada uma porcentagem percentual
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);
Tso = 0.97;
K1 = 369;
wn = 4/(Tso*ep);
Ts = feedback(K1*Gs,1);
Zc = 7;

x = -wn*ep + i*wn*(1 - ep^2)^0.5;
Gx = 1/((x+15)*(x^2 + 6*x + 13));

angleX = radtodeg(angle((x + Zc)*Gx));
AngC = 180 + angleX;

Pc = imag(x)/tan(degtorad(AngC)) - real(x);

Gc = (s + Zc)/(s + Pc);
Gcx = (x + Zc)/(x + Pc);

K = abs(Gcx*Gx)^-1;

Tsc = feedback(K*Gc*Gs,1);

step(Tsc,Ts); 
grid on;
legend('Tsc','Ts');

%% Quest�o 15
clear all;
clc;

s = tf('s');
Gs = 1/(s*(s+1)*(s^2 + 10*s + 26));
Up = 0.15;
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);
K = 14.4;
Ts = feedback(K*Gs,1);

Tso = 7;
Wno = 4/(Tso*ep);

Pc = 15;
x = -Wno*ep + i*Wno*(1 - ep^2)^.5
Gx = 1/(x*(x+1)*(x^2 + 10*x + 26));
AngleX = radtodeg(angle(Gx/(x+Pc)));
AngC = 180 - AngleX;

Zc = imag(x)/tan(degtorad(AngC)) - real(x); 


Gc = (s + Zc)/(s + Pc);
Gcx = (x + Zc)/(x + Pc);
K = abs(Gcx*Gx)^-1;

Tsc = feedback(K*Gc*Gs,1);
step(Tsc,Ts);
grid on;
legend('Tsc','Ts');