%% Quest�o 16
clear all;
clc;
s = tf('s');
Gs = 1/(s^2*(s+4)*(s+12));
Up = 0.205;
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);

Ts = feedback(Gs,1);

x = -1.333 + i*2.643;

Gx = 1/(x^2*(x+4)*(x+12));
Angle = radtodeg(angle(x*Gx));

AngC = 180 + Angle;

Gc = (s + 0.001)/(s+34.34);
Gcx = (x)/(x+34.34);

K = abs(Gx*Gcx)^-1

Tsc = feedback(K*Gc*Gs,1);

step(Tsc);
grid on;
legend('Tsc');

%% Quest�o 17
clear all;
clc;

s = tf('s');
Gs = 1/((s^2 + 20*s + 101)*(s + 20));
ep = 0.4;
Tso = 0.5;
K = 3350;
Ts = feedback(K*Gs,1);

wn = 4/(Tso*ep);
x = -wn*ep + i*wn*(1 - ep^2)^.5;
Gx = 1/((x^2 + 20*x + 101)*(x + 20));

Angle = radtodeg(angle(Gx/(x+15)));
Pc = imag(x)/tan(degtorad(180-Angle)) - real(x);
Gc = (s + Pc)/(s + 15);
Gcx = (x + Pc)/(x + 15);

K = abs(Gcx*Gx)^-1;

Tsc = feedback(K*Gc*Gs,1);
step(Tsc,Ts);
grid on;
legend('Tsc','Ts');

%% Quest�o 21 - Avan�o e Atraso

clear all;
clc;

%               Avanco                    Atraso
%   Gc = Kc*((s + 1/T1)/(s + Y/T1))*((s + 1/T2)/(s + 1/(T2*b)))
%
%

s = tf('s');
Gs = 1/(s*(s+1)*(s+3));
Up = 0.0432;
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);
K = 1.11;

Ts = feedback(K*Gs,1);

Tso = 2.86;
wn = 4/(Tso*ep);
x = -wn*ep + i*wn*(1 - ep^2)^.5;
Gx = 1/(x*(x+1)*(x+3));
Angle = radtodeg(angle(Gx*(x+1)));
AngC = 180 + Angle;
ZcA = 1;
PcA = imag(x)/tan(degtorad(AngC)) - real(x);

GcA = (s + 1)/(s + 22.11);
GcAx = (x + 1)/(x + 22.11);
Kc = abs(GcAx*Gx)^-1

Gca = (s + 0.1)/(s + 9.04e-3);

Tsc = feedback(Kc*GcA*Gca*Gs,1);


step(1/s,Tsc/s,Ts/s);


step(1/s,Tsc/s,Ts/s);
grid on;
legend('In','Tsc','Ts');

%% Quest�o 22

clear all;
clc;

s = tf('s');
Gs = 1/(s*(s+5)*(s+11));
Up = 0.15;
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);
K1 = 219;

Ts = feedback(K1*Gs,1);
step(Ts);

x = -4.151 + i*6.874;
Gx = 1/(x*(x+5)*(x+11));
Angle = radtodeg(angle(Gx*(x+5)));
AngC = 180 + Angle

Gc = (s + 5)/(s + 32.22);
Gcx = (x + 5)/(x + 32.22)
K = abs(Gcx*Gx)^-1;
Gca = (s + 0.1)/(s + 18.62e-3);
TscA = feedback(K*Gc*Gs,1);
TscAT = feedback(K*Gca*Gc*Gs,1)

step(1/s,TscAT/s,Ts/s);
grid on;
legend('In','TsComp','Ts');

%% Quest�o 23

clear all;
clc;

s = tf('s');
Gs = 1/((s^2 + 4*s + 8)*(s+10));
K1 = 21.1;
Ts = feedback(K1*Gs,1);

ep = 0.5;
Tso = 0.9;
wn = 4/(Tso*ep);
x = -wn*ep + i*wn*(1 - ep^2)^.5;
Gx = 1/((x^2 + 4*x + 8)*(x+10));
Zc = 3;
Angle = radtodeg(angle(Gx*(x + Zc)));

AngC = 180 + Angle;
Pc = imag(x)/tan(degtorad(AngC)) - real(x);
GcA = (s + Zc)/(s + Pc);
Gcx = (x + Zc)/(x + Pc);

K = abs(Gcx*Gx)^-1
GscA = GcA*Gs*K;
TscA = feedback(K*GcA*Gs,1);
Gca = (s + 0.5)/(s + 0.0145);
TscT = feedback(K*Gca*GcA*Gs,1);
step(TscT,TscA,Ts);
grid on;
legend('TscT','TscA','Ts');
