%% Quest�o 01
clear all;
clc;

%1 Etapa - Ajustar Ganho e ver como o Sistema se comporta
s = tf('s');
Gs = 1/((s+1)*(s+3)*(s+10));
rltool; 
K = 73; %Valor Obtido do RLTool
Ts = feedback(K*Gs,1);

%2 Etapa - Fazendo o PI
Gc = (s+0.1)/s; %PI Padr�o, Resolve o Problema
Tsc = feedback(K*Gc*Gs,1);

%Resultados
step(Ts,Tsc);
grid on;
legend('Ts','Tsc');

%% Quest�o 02
clear all;
clc;

s = tf('s');
Gs = 1/(s*(s+3)*(s+6));
Gc = (s+0.1)/s;
Ts = feedback(Gs,1);
Tsc = feedback(Gc*Gs,1);
step(Ts/s,Tsc/s,1/s);
grid on;
legend('Out','Out c','In');

%% Quest�o 03 ===> Tutorial do Atraso
clear all;
clc;
s = tf('s');
Gs = 1/((s+2)*(s+3)*(s+7));
Up = 10/100; % � dada uma porcentagem percentual
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);

%Achar o K para a condicao de EP com rltool
rltool;
K = 41.1;
Ts = feedback(K*Gs,1);


Pc = 0.01; % Define-se o polo do compensador
x = 0; % Para x = 0, acha-se o Kpa
Kpa = (1/((x+2)*(x+3)*(x+7)))*K; % Acha-se o Kpatual
Kpobj = 4; % Kp objetivo
Zc = Kpobj*Pc/Kpa;
Gc = (s + Zc)/(s + Pc);
Tsc = feedback(K*Gc*Gs,1);
step(Ts,Tsc);
grid;
legend('Ts','Tsc');

%% Quest�o 04 - Atraso para outra Ft
clear all;
clc;
s = tf('s');
Gs = 1/(s*(s+3)*(s+7));
Up = 10/100; % � dada uma porcentagem percentual
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);

%Achar o K para a condicao de EP com rltool
rltool;
K = 28;
Ts = feedback(K*Gs,1);

Pc = 0.005; % Define-se o polo do compensador
x = 0; % Para x = 0, acha-se o Kpa
Kpa = (1/((x+3)*(x+7)))*K; % Acha-se o Kpatual
Kpobj = 4; % Kp objetivo
Zc = Kpobj*Pc/Kpa;
Gc = (s + Zc)/(s + Pc);
Tsc = feedback(K*Gc*Gs,1);
step(Ts/s,Tsc/s,1/s);
grid;
legend('Ts','Tsc');

%% Quest�o 05 - Atraso de Fase

clear all;
clc;
s = tf('s');
Gs = 1/((s+3)*(s+5)*(s+7));
Up = 10/100; % � dada uma porcentagem percentual
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);

%Achar o K para a condicao de EP com rltool
rltool;
K = 87.7;
Ts = feedback(K*Gs,1);

Pc = 0.005; % Define-se o polo do compensador
x = 0; % Para x = 0, acha-se o Kpa
Kpa = (1/((x+3)*(x+5)*(x+7)))*K; % Acha-se o Kpatual
Kpobj = 20; % Kp objetivo
Zc = Kpobj*Pc/Kpa;
Gc = (s + Zc)/(s + Pc);
Tsc = feedback(K*Gc*Gs,1);
step(1 - Ts,1 - Tsc);
grid;
legend('Ts','Tsc');