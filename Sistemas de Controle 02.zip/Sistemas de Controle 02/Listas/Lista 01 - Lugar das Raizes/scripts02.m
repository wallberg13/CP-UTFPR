%% Quest�o 06 - Confec��o de um PD
clear all;
clc;

s = tf('s');
Gs = (s+6)/((s+2)*(s+3)*(s+5));
ep = 0.707;

% Fechando a malha
Ts = feedback(4.6*Gs,1);
step(Ts);

%Achando Wnobj
Tsa = 1.83; % Setting Time poderia ter sido pego da equa��o de Segunda ordem
Tsobj = Tsa/2;
Wnobj = 4/(Tsobj*ep);

%Achando os Polos Obj
Sobj = -ep*Wnobj + i*Wnobj*(1-ep^2)^.5;
Gso = (Sobj+6)/((Sobj+2)*(Sobj+3)*(Sobj+5));
%Contribui��o Angular:
angleX = radtodeg(angle(Gso));
AngC = 180 - angleX;

% Calculando o Zero
% A contribuicao de um zero no polo objetivo � positiva
% e � calculado tg(AngC) = imag(Sobj)/(real(Sobj) + Zc);
% Isolando Zc tempo : imag(Sobj)/tan(degtorad(AngC)) - real(Sobj)
Zc = imag(Sobj)/tan(degtorad(AngC)) - real(Sobj);
Gc = s + Zc;
Gcs = Sobj + Zc;
K = 1/(abs(Gcs*Gso));
Gcs = K*Gc*Gs;
rltool;
% Para testar o compensador.
Tsc = feedback(K*Gc*Gs,1);
step(Tsc,Ts);
grid on;
legend('Tsc','Ts');

%% Quest�o 08
clear all;
clc;
s = tf('s');
Gs = 1/(s*(s+10)*(s+20));
Up = 20/100; % � dada uma porcentagem percentual
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);
K1 = 1160;
Ts = feedback(K1*Gs,1);
step(Ts);

% Achando o Tso, Wno e Sobj;
Tsa = 1.23;
Tso = Tsa/4;
Wno = 4/(ep*Tso);
Sobj = -Wno*ep + i*Wno*(1 - ep^2)^.5
Gso = 1/(Sobj*(Sobj+10)*(Sobj+20))

%Contribui��o Angular:
angleX = radtodeg(angle(Gso))
AngC = 180 - angleX

% Calculando o Zero
% A contribuicao de um zero no polo objetivo � positiva
% e � calculado tg(AngC) = imag(Sobj)/(real(Sobj) + Zc);
% Isolando Zc tempo : imag(Sobj)/tan(degtorad(AngC)) - real(Sobj)
Zc = imag(Sobj)/tan(degtorad(AngC)) - real(Sobj);
Gc = s + Zc;
Gcs = Sobj + Zc;
K = 1/(abs(Gcs*Gso));
Gcs = K*Gc*Gs;
% Para testar o compensador.
Tsc = feedback(K*Gc*Gs,1);
step(Tsc,Ts);
grid on;
legend('Tsc','Ts');

%% Quest�o 09 - Avan�o de Fase - � questionavel

clear all;
clc;
s = tf('s');
Gs = 1/(s+4)^3;
Up = 25/100; % � dada uma porcentagem percentual
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);
K1 = 93.5;
Ts = feedback(K1*Gs,1);
step(Ts);

Tso = 1.6;
Wno = 4/(ep*Tso);
Sobj = -Wno*ep + i*Wno*(1 - ep^2)^.5

% Escolhe-se um lugar para ser zero, e
% veja a contribui��o angular que ele tras no sistema
Zc = 1;
angleX = radtodeg(angle((Sobj+Zc)/(Sobj+4)^3))

Gc = (s + 1)/(s + 5.86);
Gco = (Sobj + 1)/(Sobj + 5.86);
Gso = 1/(Sobj+4)^3;
K = abs(Gco*Gso)^-1;
Tsc = feedback(K*Gc*Gs,1);

Gsc = K*Gs*Gc;

step(Tsc,Ts);
grid on;
legend('Tsc','Ts');