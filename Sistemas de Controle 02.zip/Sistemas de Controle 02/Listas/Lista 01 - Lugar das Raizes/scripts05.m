%% Quest�o 25 - PID

clear all;
clc;
s = tf('s');
Gs = 1/((s+1)*(s+4));
K = 5.77;
Ts = feedback(K*Gs,1);
step(Ts);

Tp = 1.047;
ep = 0.8;
wn = pi/(Tp*(1 - ep^2)^.5);
x = -wn*ep + i*wn*(1-ep^2)^.5
Gx = 1/((x+1)*(x+4));
Angle = radtodeg(angle(Gx));
AngleC = 180 - Angle;
Zc = imag(x)/tan(AngleC) - real(x);

Gd = s + Zc;
Gdx = x + Zc;
Gi = (s + 0.1)/s;
Gix = (x + 0.1)/x;
K = abs(Gix*Gdx*Gx)^-1;

Tsc = feedback(K*Gd*Gi*Gs,1);
step(Tsc,Ts);
grid on;
legend('Tsc','Ts');