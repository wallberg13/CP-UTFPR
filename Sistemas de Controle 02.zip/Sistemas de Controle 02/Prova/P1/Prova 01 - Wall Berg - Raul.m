%% Quest�o 02 - Prova

clear all;
clc;

s = tf('s');
Gs = 10e5/((s^2-4551)*(s+286));
TsNC = feedback(Gs,10); 

Ts = 0.099;
Up = 0.03;
ep = -log(Up)/((pi^2 + log(Up)^2)^0.5);
wn = 4/(ep*Ts);

Pc = 450;

x = -wn*ep + i*wn*(1 - ep^2)^.5;
Gx = 10e5/((x^2 -4551)*(x+286));
Angle = radtodeg(angle(Gx/(x + Pc)))
AngC = 180 - Angle;

Zc = imag(x)/tan(degtorad(AngC)) - real(x)

Gc = (s + Zc)/(s + Pc);
Gcx = (x + Zc)/(x + Pc);

K = abs(Gx*Gcx)^-1
Tsc = 10*feedback(Gc*Gs,10);

figure;
step(Tsc);
grid on;
legend('Tsc');
title('Questao 02 - Letra A');

%% Quest�o 01
clear all;
clc;

s = tf('s');
Gs = 4/(s*(s+1)*(s+2));

%Letra A
figure;
K = 334.97e-3;
bode(K*Gs,Gs);
grid on;
title('Questao 01 - Letra A');

%Letra B
K1 = 0.5;
Gc = K1*(s + 0.0466)/(s + 0.00258);
figure();
bode(K*Gc*Gs,Gs*K);
grid on;
title('Quest�o 01 - Letra B');
