#include "Funcoes.h"
#include<stdlib.h>
#include<stdio.h>
int menu_maroto(PokeAgenda **l);
void gets_char();

int main(){
	PokeAgenda *l;
	menu_maroto(&l);
}

int menu_maroto(PokeAgenda **l){
	int resp = 1;
	int maroto;
	char nome[15];
	inicializar_lista(l);
	
	char arquivo[]="pokemon.txt";
	importar_lista(l,arquivo);	
	printf("Arquivo Importado!! \n");
	gets_char();
	
	while(resp != 0){
		system("clear");
		printf("----->Pokedex do Wall Berg Morais<-----\n\n");
		printf("01 - Listar Pokedex em Ordem Crescente \n");
		printf("02 - Lista Pokedex em Ordem Decrescente \n");
		printf("03 - Pesquisar Pokemon por nome \n");
		printf("04 - Remover Pokemon por Numero \n");
		printf("00 - Terminar a execucao! \n");
		printf("Resposta: ");
		scanf("%d",&resp);
		system("clear");
		switch(resp){
			case 1: 
				listar_pokemon_crescente(l);
				gets_char();
				break;
			case 2:
				listar_pokemon_decrescente(l);
				gets_char();
				break;
			case 3:
				printf("Digite o nome do pokemon: ");
				__fpurge(stdin);
				scanf("%[^\n]s",nome);
				pesquisar_poke_nome(l,nome);
				gets_char();
				break;
			case 4:
				printf("Digite o numero do Pokemon que deseja excluir: ");
				__fpurge(stdin);
				scanf("%d",&maroto);
				remover_por_numero(l,maroto);
				gets_char();
				break;
			case 0:
				destruir_pokedex(l);
				system("exit");
		}
	}
}

void gets_char(){
	system("read a");
}