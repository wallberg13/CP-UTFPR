#include "Funcoes.h"

int main(){
	char arquivo[] = "casos_teste.txt";
	importar_arquivo(arquivo);
}