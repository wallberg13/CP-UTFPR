interface ObjetoGeometrico{
    public static final double pi = 3.14159;
    
    public Ponto2D centro();
    
    public double calculaArea();
    
    public String toString();
}