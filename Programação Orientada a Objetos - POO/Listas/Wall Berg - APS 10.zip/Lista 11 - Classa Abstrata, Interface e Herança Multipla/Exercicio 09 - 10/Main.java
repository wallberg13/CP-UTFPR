public class Main{
    
    public static void main(String[] args){
	System.out.println("Na verdade não acontece nada, pois o metodo "+
	+" toString() já está implementada implicitamente, pois é um metodo"+
	+" da classe Objeto do java, mas se o metodo na interface tivesse outro nome"+
	+" iria dá erro. ");
    }
}
