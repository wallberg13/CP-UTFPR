public class Main{
  
  public static void main(String[] args){
    Reais real = new Reais(333.00);
    real.imprimeExtenso();
    real.imprime();
  }
  
}