public class Biblioteca{
    private Revista[] revista;

}