public class Main{
  
  public static void main(String[] args){
    
    Data.imprimirExtenso(32,13,2013);
    Data.imprimirExtenso(02,12,2013);
    Data.imprimirExtenso(31,03);
    Data.imprimirExtenso(31);
    
    Data.imprimirMes(2);
    Data.imprimirExtenso(13,12,2015);
    Data.imprimirExtenso(13,12,2017);
    Data.Diferenca(13,12,2015,13,11,2014);
    
  }
}