/*
  Arquivo SQL destinado para criações de funções dentro da base de dados da
  TGas
*/
