/*
  Arquivo SQL destinado para criações de Indices dentro da base de dados da
  TGas
*/

/**
  Consultas corriqueiras, saber qual foram os produtos para
  determinada venda

  Qual Funcionario que Realizou determinada Venda

  Quantidade de compras que o Cliente X Possui


*/
