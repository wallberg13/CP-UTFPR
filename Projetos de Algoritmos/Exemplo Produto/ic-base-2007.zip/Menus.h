/* Menu de geracao de uma solucao inicial */
int menu_solucao_inicial(void);

/* Menu principal */
int menu_principal(void);

/* Menu GRASP */
int menu_GRASP(void);


/* Menu Algoritmos Geneticos */
int menu_AG(void);






 