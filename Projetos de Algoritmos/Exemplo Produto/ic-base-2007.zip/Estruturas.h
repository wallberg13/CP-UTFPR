struct lista {
	int campo1;
        int campo2;
        float campo3;
  	struct lista *proximo;  /* ponteiro para a pr�xima entrada */
  	struct lista *anterior; /* ponteiro para o registro anterior */
};

 