#include "headers.h"

/**
   FICA EM STAND BY
*/
/*
void tsp_dynamic(int **mtz, int n){
  //face
}

/*
  Entradas: e_a  : Etapa atual.
            des  : Destino desejado.
            org  : Lugar inicial.
            test : Matriz de adjacencias da solução.
            n    : Tamanho do Vetor.

int verifica_ciclo(int n,Test test[n][n],int e_a,int des, int org){

}
*/
