#include "headers.h"

int main(int argc, char *arg[]){
  sorteio();
  clock_t t = clock();
  if(argc > 2){
    import(arg[1],arg[2]);
    t = clock() - t;
  }
  double t_med = t/(double)CLOCKS_PER_SEC;
}
