#include<stdio.h>
#include "Funcoes.h"

int main(){
  no *l;
  iniLista(&l);
  addPrimos(&l);
  imprimeLista(&l);
  printf("Antes de Destruir\n \n");
  destruirLista(&l);
  printf("Destruida \n \n");
  imprimeLista(&l);
}