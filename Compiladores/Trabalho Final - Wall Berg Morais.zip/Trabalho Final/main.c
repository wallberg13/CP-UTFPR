#include "headers.h"
#include<stdio.h>
int main(int argc, char *argv[]){
  if(argc>1)
    read_file(argv[1]);
}
