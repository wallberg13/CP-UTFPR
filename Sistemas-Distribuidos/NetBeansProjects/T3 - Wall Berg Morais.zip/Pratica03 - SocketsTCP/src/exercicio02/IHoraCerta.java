/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio02;

/**
 *
 * @author sir-berg
 */
public interface IHoraCerta {
    
    /**
     * Função que retorna a data atual do sistema.
     * @return String
     */
    public String dataAtual();

    /**
     * Função que retorna a hora atual do sistema.
     * @return 
     */
    public String horaAtual();
    
}
